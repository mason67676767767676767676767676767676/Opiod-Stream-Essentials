Opiod Stream Essentials — combined Fabric client mod
Minecraft 1.21.11 • Java 21

This project combines:
- The existing Donut Auction mod from libs/donut-auction-original.jar
- The Opiod Stream Essentials themes, settings screen, and balance HUD source

The output JAR is named Opiod-Stream-Essentials-1.0.0.jar.

BUILD:
1. Upload the contents of this folder to a new GitHub repository.
2. Open Actions.
3. Choose "Build Opiod Stream Essentials".
4. Select Run workflow.
5. Download the Opiod-Stream-Essentials artifact.

The workflow compiles the new Java sources and merges the original auction mod's
compiled classes/resources into the same JAR. This environment could not run
Gradle, so the combined JAR has not yet been compiled or runtime-tested.

Both original client entrypoints are retained in one Fabric mod metadata file.
