package com.ninestyle;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    public int theme = 0;
    public boolean hudEnabled = true;
    public int hudX = 8, hudY = 8;
    public int hudBg = 0, hudText = 1, hudOpacity = 2;
    public int checkSeconds = 10;
    public boolean hideReply = true;

    private static Config inst;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("ninestyle.json");
    }

    public static Config get() {
        if (inst == null) load();
        return inst;
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) inst = GSON.fromJson(Files.readString(p), Config.class);
        } catch (Exception ignored) {}
        if (inst == null) inst = new Config();
        inst.clamp();
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(get()));
        } catch (Exception ignored) {}
    }

    private void clamp() {
        theme = Math.floorMod(theme, Theme.values().length);
        hudBg = Math.floorMod(hudBg, Palette.HUD_BG.length);
        hudText = Math.floorMod(hudText, Palette.HUD_TEXT.length);
        hudOpacity = Math.floorMod(hudOpacity, Palette.OPACITY_PCT.length);
        if (checkSeconds < 5) checkSeconds = 5;
        if (hudX < 0) hudX = 0;
        if (hudY < 0) hudY = 0;
    }
}
