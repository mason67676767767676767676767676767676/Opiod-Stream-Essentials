package com.ninestyle;

import net.minecraft.client.MinecraftClient;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Periodically runs /bal, reads the chat reply, tracks balance changes. */
public final class BalanceTracker {
    private BalanceTracker() {}

    private static final Pattern MONEY =
            Pattern.compile("\\$\\s*([\\d,]+(?:\\.\\d+)?)\\s*([kKmMbBtT])?(?![A-Za-z])");

    public static double balance = Double.NaN;
    public static double previous = Double.NaN;
    public static double lastChange = Double.NaN;

    private static long awaitUntil = 0;
    private static int sinceJoin = 0;
    private static int sinceCheck = 100000;

    public static boolean hasData() {
        return !Double.isNaN(balance);
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.getNetworkHandler() == null) {
            sinceJoin = 0;
            sinceCheck = 100000;
            return;
        }
        Config cfg = Config.get();
        if (!cfg.hudEnabled) return;
        sinceJoin++;
        sinceCheck++;
        if (sinceJoin < 80) return; // let the join settle
        if (sinceCheck >= cfg.checkSeconds * 20) {
            sinceCheck = 0;
            awaitUntil = System.currentTimeMillis() + 4000;
            mc.getNetworkHandler().sendChatCommand("bal");
        }
    }

    /** @return true if this message was our /bal reply (and should be hidden, if enabled). */
    public static boolean onMessage(String msg, boolean overlay) {
        if (overlay || System.currentTimeMillis() > awaitUntil) return false;
        String low = msg.toLowerCase();
        if (!low.contains("balance")) return false;
        if (low.contains("paid") || low.contains("received") || low.contains("sent")) return false;

        Matcher m = MONEY.matcher(msg);
        if (!m.find()) return false;
        double v;
        try {
            v = Double.parseDouble(m.group(1).replace(",", ""));
        } catch (NumberFormatException e) {
            return false;
        }
        String suf = m.group(2);
        if (suf != null) {
            switch (Character.toLowerCase(suf.charAt(0))) {
                case 'k' -> v *= 1e3;
                case 'm' -> v *= 1e6;
                case 'b' -> v *= 1e9;
                case 't' -> v *= 1e12;
                default -> {}
            }
        }
        if (Double.isNaN(balance)) {
            balance = v;
        } else if (v != balance) {
            previous = balance;
            lastChange = v - balance;
            balance = v;
        }
        awaitUntil = 0;
        return Config.get().hideReply;
    }
}
