package com.ninestyle;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

public class NineStyleClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Config.load();

        HudElementRegistry.addLast(Identifier.of("ninestyle", "balance"),
                (context, tickCounter) -> BalanceHud.render(context));

        ClientTickEvents.END_CLIENT_TICK.register(BalanceTracker::tick);

        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) ->
                !BalanceTracker.onMessage(message.getString(), overlay));

        // /9ugh opens the theme + HUD settings
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("9ugh").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new SettingsScreen()));
                    return 1;
                })));
    }
}
