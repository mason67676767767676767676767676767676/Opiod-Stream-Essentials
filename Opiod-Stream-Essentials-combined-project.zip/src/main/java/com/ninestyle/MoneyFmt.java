package com.ninestyle;

import java.util.Locale;

public final class MoneyFmt {
    private MoneyFmt() {}

    /** 125450 -> $125k, 1200000 -> $1.2m, 950 -> $950 */
    public static String compact(double v) {
        boolean neg = v < 0;
        double a = Math.abs(v);
        String s;
        if (a >= 1e12) s = scale(a / 1e12) + "t";
        else if (a >= 1e9) s = scale(a / 1e9) + "b";
        else if (a >= 1e6) s = scale(a / 1e6) + "m";
        else if (a >= 1e3) s = scale(a / 1e3) + "k";
        else s = String.valueOf(Math.round(a));
        return (neg ? "-" : "") + "$" + s;
    }

    /** +$2.5k / -$500 */
    public static String signed(double v) {
        return (v > 0 ? "+" : "") + compact(v);
    }

    private static String scale(double x) {
        if (x >= 100) return String.valueOf(Math.round(x));
        String t = String.format(Locale.ROOT, "%.1f", x);
        return t.endsWith(".0") ? t.substring(0, t.length() - 2) : t;
    }
}
