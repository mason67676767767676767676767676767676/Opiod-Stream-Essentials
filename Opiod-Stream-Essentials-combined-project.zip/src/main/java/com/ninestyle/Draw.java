package com.ninestyle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Rounded/pill drawing and bubbly text helpers. */
public final class Draw {
    private Draw() {}

    // If this line fails to compile on your mappings, replace with: Style.EMPTY (no custom font).
    private static final Style BUBBLY =
            Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("ninestyle", "bubbly")));

    public static Text t(String s) {
        return Text.literal(s).setStyle(BUBBLY);
    }

    public static int width(String s) {
        return MinecraftClient.getInstance().textRenderer.getWidth(t(s));
    }

    public static void text(DrawContext c, String s, int x, int y, int color) {
        c.drawText(MinecraftClient.getInstance().textRenderer, t(s), x, y, color, false);
    }

    /** Filled rounded rectangle (r = corner radius; r = h/2 gives a pill). */
    public static void round(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
        c.fill(x, y + r, x + w, y + h - r, color);
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
