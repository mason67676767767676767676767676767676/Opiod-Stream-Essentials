package com.ninestyle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class BalanceHud {
    private BalanceHud() {}

    private static final int PAD = 6;
    private static final float BIG = 1.6f;
    private static final int GREEN = 0xFF5CFF9D, RED = 0xFFFF6B6B, GRAY = 0xFFA0A8B4;

    private record Vals(String big, String chg, String prev, int chgColor) {}

    private static Vals vals(boolean preview) {
        double bal = preview ? 125450 : BalanceTracker.balance;
        double chg = preview ? 2500 : BalanceTracker.lastChange;
        double prev = preview ? 122950 : BalanceTracker.previous;
        String big = Double.isNaN(bal) ? "$--" : MoneyFmt.compact(bal);
        String c = Double.isNaN(chg) ? "--" : MoneyFmt.signed(chg);
        String p = Double.isNaN(prev) ? "--" : MoneyFmt.compact(prev);
        int col = Double.isNaN(chg) ? GRAY : (chg > 0 ? GREEN : (chg < 0 ? RED : GRAY));
        return new Vals(big, c, p, col);
    }

    public static int[] size(boolean preview) {
        Vals v = vals(preview);
        int bigW = (int) Math.ceil(Draw.width(v.big) * BIG);
        int r1 = Draw.width("Change") + 10 + Draw.width(v.chg);
        int r2 = Draw.width("Previous") + 10 + Draw.width(v.prev);
        int w = Math.max(96, Math.max(Draw.width("YOUR BALANCE"), Math.max(bigW, Math.max(r1, r2))) + PAD * 2);
        return new int[]{w, 64};
    }

    /** Called by the in-game HUD registration. */
    public static void render(DrawContext c) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config cfg = Config.get();
        if (!cfg.hudEnabled || mc.options.hudHidden) return;
        if (mc.currentScreen instanceof SettingsScreen) return; // the screen draws it itself
        int[] s = size(false);
        int x = Math.min(cfg.hudX, Math.max(0, mc.getWindow().getScaledWidth() - s[0]));
        int y = Math.min(cfg.hudY, Math.max(0, mc.getWindow().getScaledHeight() - s[1]));
        draw(c, x, y, false);
    }

    public static void draw(DrawContext c, int x, int y, boolean preview) {
        Config cfg = Config.get();
        Vals v = vals(preview);
        int[] s = size(preview);
        int w = s[0], h = s[1];

        int alpha = (int) (255 * (Palette.OPACITY_PCT[cfg.hudOpacity] / 100f));
        int bg = (alpha << 24) | (Palette.HUD_BG[cfg.hudBg] & 0xFFFFFF);
        int accent = Palette.HUD_TEXT[cfg.hudText];

        Draw.round(c, x, y, w, h, 7, bg);

        Draw.text(c, "YOUR BALANCE", x + PAD, y + PAD, GRAY);
        Draw.round(c, x + PAD, y + PAD + 11, 18, 2, 1, accent);

        c.getMatrices().pushMatrix();
        c.getMatrices().translate(x + PAD, y + PAD + 15);
        c.getMatrices().scale(BIG, BIG);
        Draw.text(c, v.big, 0, 0, accent);
        c.getMatrices().popMatrix();

        int ry = y + PAD + 32;
        Draw.text(c, "Change", x + PAD, ry, GRAY);
        Draw.text(c, v.chg, x + w - PAD - Draw.width(v.chg), ry, v.chgColor);
        Draw.text(c, "Previous", x + PAD, ry + 10, GRAY);
        Draw.text(c, v.prev, x + w - PAD - Draw.width(v.prev), ry + 10, 0xFFE6EAF0);
    }
}
