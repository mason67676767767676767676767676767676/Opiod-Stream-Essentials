package com.ninestyle;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/**
 * Theme picker + balance HUD settings. Immediate-mode UI that polls the mouse via GLFW,
 * so it doesn't depend on Screen mouse-method signatures that change between versions.
 */
public class SettingsScreen extends Screen {
    private final Map<String, Float> hover = new HashMap<>();
    private boolean prevDown, justPressed, dragging, blocked;
    private int dragDX, dragDY, mx, my;

    public SettingsScreen() {
        super(Text.literal("9ugh Style"));
    }

    @Override
    protected void init() {
        prevDown = down();
    }

    private static boolean down() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        Config cfg = Config.get();
        Theme th = Theme.of(cfg.theme);
        mx = mouseX;
        my = mouseY;
        boolean isDown = down();
        justPressed = isDown && !prevDown;
        prevDown = isDown;

        // background + panel
        c.fill(0, 0, width, height, th.bg);
        int pw = 280, ph = 224;
        int px = (width - pw) / 2, py = Math.max(2, (height - ph) / 2);
        Draw.round(c, px, py, pw, ph, 10, Draw.mix(th.panel, th.accent, 0.45f));
        Draw.round(c, px + 1, py + 1, pw - 2, ph - 2, 9, th.panel);

        // HUD grab / drag (HUD is drawn on top, so it gets input priority)
        boolean preview = !BalanceTracker.hasData();
        int[] hs = BalanceHud.size(preview);
        blocked = false;
        if (justPressed && mx >= cfg.hudX && mx < cfg.hudX + hs[0] && my >= cfg.hudY && my < cfg.hudY + hs[1]) {
            dragging = true;
            blocked = true;
            dragDX = mx - cfg.hudX;
            dragDY = my - cfg.hudY;
        }
        if (dragging) {
            if (isDown) {
                cfg.hudX = clamp(mx - dragDX, 0, Math.max(0, width - hs[0]));
                cfg.hudY = clamp(my - dragDY, 0, Math.max(0, height - hs[1]));
            } else {
                dragging = false;
                Config.save();
            }
        }

        String title = "9ugh Style";
        Draw.text(c, title, px + (pw - Draw.width(title)) / 2, py + 10, th.accent);
        Draw.text(c, "Background Theme", px + 10, py + 26, th.sub);

        // theme swatches (2 columns x 4 rows)
        Theme[] all = Theme.values();
        for (int i = 0; i < all.length; i++) {
            Theme t = all[i];
            int bx = px + 8 + (i % 2) * 134;
            int by = py + 38 + (i / 2) * 19;
            final int idx = i;
            boolean sel = cfg.theme == i;
            btn(c, "theme" + i, bx, by, 128, 16, t.label, t.panel, sel ? th.text : t.accent, t.text, () -> {
                cfg.theme = idx;
                Config.save();
            });
            Draw.round(c, bx + 7, by + 4, 8, 8, 4, t.accent);
        }

        Draw.text(c, "Balance Tracker  (/bal)", px + 10, py + 118, th.sub);

        int c1 = px + 8, c2 = px + 142, bw = 128, bh = 16;
        int fill = Draw.mix(th.panel, th.accent, 0.16f);
        int bord = Draw.mix(th.panel, th.accent, 0.5f);

        btn(c, "hud", c1, py + 130, bw, bh, "HUD: " + (cfg.hudEnabled ? "On" : "Off"), fill, bord, th.text, () -> {
            cfg.hudEnabled = !cfg.hudEnabled;
            Config.save();
        });
        btn(c, "box", c2, py + 130, bw, bh, "Box: " + Palette.HUD_BG_NAMES[cfg.hudBg], fill, bord, th.text, () -> {
            cfg.hudBg = (cfg.hudBg + 1) % Palette.HUD_BG.length;
            Config.save();
        });
        btn(c, "txt", c1, py + 149, bw, bh, "Text: " + Palette.HUD_TEXT_NAMES[cfg.hudText], fill, bord, th.text, () -> {
            cfg.hudText = (cfg.hudText + 1) % Palette.HUD_TEXT.length;
            Config.save();
        });
        btn(c, "opa", c2, py + 149, bw, bh, "Opacity: " + Palette.OPACITY_PCT[cfg.hudOpacity] + "%", fill, bord, th.text, () -> {
            cfg.hudOpacity = (cfg.hudOpacity + 1) % Palette.OPACITY_PCT.length;
            Config.save();
        });
        btn(c, "chk", c1, py + 168, bw, bh, "Check every " + cfg.checkSeconds + "s", fill, bord, th.text, () -> {
            int cur = 0;
            for (int i = 0; i < Palette.INTERVALS.length; i++) if (Palette.INTERVALS[i] == cfg.checkSeconds) cur = i;
            cfg.checkSeconds = Palette.INTERVALS[(cur + 1) % Palette.INTERVALS.length];
            Config.save();
        });
        btn(c, "hide", c2, py + 168, bw, bh, "Hide reply: " + (cfg.hideReply ? "On" : "Off"), fill, bord, th.text, () -> {
            cfg.hideReply = !cfg.hideReply;
            Config.save();
        });
        btn(c, "reset", c1, py + 187, bw, bh, "Reset position", fill, bord, th.text, () -> {
            cfg.hudX = 8;
            cfg.hudY = 8;
            Config.save();
        });
        btn(c, "done", c2, py + 187, bw, bh, "Done", th.accent, th.accent, th == Theme.ICE ? 0xFFFFFFFF : 0xFF10141A, () ->
                MinecraftClient.getInstance().setScreen(null));

        String hint = "Drag the balance box to move it";
        Draw.text(c, hint, px + (pw - Draw.width(hint)) / 2, py + 207, th.sub);

        // HUD on top
        BalanceHud.draw(c, cfg.hudX, cfg.hudY, preview);
    }

    /** Pill button with smooth hover glow. */
    private void btn(DrawContext c, String id, int x, int y, int w, int h, String label,
                     int fill, int border, int textCol, Runnable action) {
        Theme th = Theme.of(Config.get().theme);
        boolean over = !blocked && mx >= x && mx < x + w && my >= y && my < y + h;
        float hv = hover.getOrDefault(id, 0f);
        hv += ((over ? 1f : 0f) - hv) * 0.3f;
        hover.put(id, hv);

        if (hv > 0.05f) {
            Draw.round(c, x - 1, y - 1, w + 2, h + 2, h / 2 + 1, Draw.mix(th.panel, th.accent, 0.55f * hv));
        }
        Draw.round(c, x, y, w, h, h / 2, Draw.mix(border, th.accent, hv * 0.6f));
        Draw.round(c, x + 1, y + 1, w - 2, h - 2, h / 2 - 1, Draw.mix(fill, th.accent, hv * 0.22f));
        Draw.text(c, label, x + (w - Draw.width(label)) / 2, y + (h - 9) / 2 + 1, textCol);

        if (over && justPressed) action.run();
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
