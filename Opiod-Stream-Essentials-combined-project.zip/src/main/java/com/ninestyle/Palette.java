package com.ninestyle;

public final class Palette {
    public static final String[] HUD_BG_NAMES = {"Dark", "Navy", "Purple", "Plum", "Forest", "Black"};
    public static final int[] HUD_BG = {0x12161C, 0x0F2236, 0x24143F, 0x3A1430, 0x0F2A20, 0x000000};

    public static final String[] HUD_TEXT_NAMES = {"White", "Mint", "Pink", "Sky", "Gold", "Orange"};
    public static final int[] HUD_TEXT = {0xFFFFFFFF, 0xFF7CF5C0, 0xFFFF8AD8, 0xFF6EC8FF, 0xFFFFE066, 0xFFFFA94D};

    public static final int[] OPACITY_PCT = {50, 70, 85, 100};
    public static final int[] INTERVALS = {5, 10, 15, 30, 60};

    private Palette() {}
}
