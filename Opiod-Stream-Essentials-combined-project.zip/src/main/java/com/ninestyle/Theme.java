package com.ninestyle;

public enum Theme {
    MIDNIGHT("Midnight",        0xFF0E1117, 0xFF171B24, 0xFF7CF5C0, 0xFFF2F5F8, 0xFF9AA4B2),
    OCEAN("Ocean Blue",         0xFF0A1F33, 0xFF112D47, 0xFF4FC3F7, 0xFFEAF6FF, 0xFF8FB4CC),
    PURPLE("Purple Dream",      0xFF1A1030, 0xFF26174A, 0xFFB388FF, 0xFFF3EDFF, 0xFFA797C9),
    PINK("Bubblegum Pink",      0xFF3A1428, 0xFF4F1D38, 0xFFFF8AD8, 0xFFFFEEF9, 0xFFD6A0C2),
    MINT("Mint Green",          0xFF0E2A22, 0xFF143B2F, 0xFF5EEAA8, 0xFFEAFFF5, 0xFF8FC4AE),
    RED("Blood Red",            0xFF2A0A0C, 0xFF3D1014, 0xFFFF5A5F, 0xFFFFEEEE, 0xFFC99093),
    ORANGE("Sunset Orange",     0xFF331A0A, 0xFF4A2610, 0xFFFFA94D, 0xFFFFF3E6, 0xFFCFA680),
    ICE("Ice White",            0xFFEAF4FB, 0xFFFFFFFF, 0xFF3AA8E0, 0xFF1B2A38, 0xFF6B7F90);

    public final String label;
    public final int bg, panel, accent, text, sub;

    Theme(String label, int bg, int panel, int accent, int text, int sub) {
        this.label = label; this.bg = bg; this.panel = panel;
        this.accent = accent; this.text = text; this.sub = sub;
    }

    public static Theme of(int i) {
        Theme[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
